/********* CHEWBACCA BUTTONS *********/
function ChangeLeft_Chewbacca() {
    document.getElementById("changeable").src = "assets/pictures/chewbacca_dynamic.png";
}

function ChangeRight_Chewbacca() {
    document.getElementById("changeable").src = "assets/pictures/chewbacca_dynamic2.png";
}

/********* R2D2 BUTTONS *********/
function ChangeLeft_R2D2() {
    document.getElementById("changeable").src = "assets/pictures/r2d2_dynamic.png";
}

function ChangeRight_R2D2() {
    document.getElementById("changeable").src = "assets/pictures/r2d2_dynamic2.png";
}

/********* C3PO BUTTONS *********/
function ChangeLeft_C3PO() {
    document.getElementById("changeable").src = "assets/pictures/c3po_dynamic.png";
}

function ChangeRight_C3PO() {
    document.getElementById("changeable").src = "assets/pictures/c3po_dynamic2.png";
}

/********* BB8 BUTTONS *********/
function ChangeLeft_BB8() {
    document.getElementById("changeable").src = "assets/pictures/bb8_dynamic.png";
}

function ChangeRight_BB8() {
    document.getElementById("changeable").src = "assets/pictures/bb8_dynamic2.png";
}